# coding=utf-8
"""Dialog tests for RedistrictingEditorDialog."""

import pytest
from qgis.core import Qgis
from qgis.PyQt.QtWidgets import QDialogButtonBox, QDialog

from redistricting_editor_dialog import RedistrictingEditorDialog

if Qgis.QGIS_VERSION_INT >= 40000:
    OK_BUTTON = QDialogButtonBox.StandardButton.Ok
    CANCEL_BUTTON = QDialogButtonBox.StandardButton.Cancel
    ACCEPTED = QDialog.DialogCode.Accepted
    REJECTED = QDialog.DialogCode.Rejected
else:
    OK_BUTTON = QDialogButtonBox.Ok
    CANCEL_BUTTON = QDialogButtonBox.Cancel
    ACCEPTED = QDialog.Accepted
    REJECTED = QDialog.Rejected


@pytest.fixture
def dialog(qgis_app):
    dlg = RedistrictingEditorDialog(None)
    yield dlg
    dlg.close()


def test_dialog_ok(dialog):
    """Clicking OK closes the dialog with Accepted."""
    dialog.button_box.button(OK_BUTTON).click()
    assert dialog.result() == ACCEPTED


def test_dialog_cancel(dialog):
    """Clicking Cancel closes the dialog with Rejected."""
    dialog.button_box.button(CANCEL_BUTTON).click()
    assert dialog.result() == REJECTED
